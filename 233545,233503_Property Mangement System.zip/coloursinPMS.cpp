#include <iostream>
#include <string>
#include <limits>
#include <windows.h>
#include <fstream>
#include <sstream>  // For stringstream
#include <iomanip> // For setw
#include <thread>
#include <chrono>
using namespace std;

class Property {
public:
    string location;
    double price;

    Property(string loc, double pr) {
        this->location = loc;
        this->price = pr;
    }
};

class AVLNode {
public:
    Property* property;
    AVLNode* left;
    AVLNode* right;
    int height;

    AVLNode(Property* prop) {
        this->property = prop;
        this->left = NULL;
        this->right = NULL;
        this->height = 1;
    }
};

class AVLTree {
public:
    AVLNode* root;

    AVLTree() {
        this->root = NULL;
    }

    int getHeight(AVLNode* node) {
        if (node == NULL) {
            return 0;
        }
        return node->height;
    }

    int getBalanceFactor(AVLNode* node) {
        if (node == NULL) {
            return 0;
        }
        return getHeight(node->left) - getHeight(node->right);
    }

    AVLNode* rotateRight(AVLNode* y) {
        AVLNode* x = y->left;
        AVLNode* T = x->right;

        x->right = y;
        y->left = T;

        y->height = max(getHeight(y->left), getHeight(y->right)) + 1;
        x->height = max(getHeight(x->left), getHeight(x->right)) + 1;

        return x;
    }

    AVLNode* rotateLeft(AVLNode* x) {
        AVLNode* y = x->right;
        AVLNode* T = y->left;

        y->left = x;
        x->right = T;

        x->height = max(getHeight(x->left), getHeight(x->right)) + 1;
        y->height = max(getHeight(y->left), getHeight(y->right)) + 1;

        return y;
    }

    AVLNode* insert(AVLNode* node, Property* property) {
	    if (!node)
	        return new AVLNode(property);
	
	    // Compare prices first
	    if (property->price < node->property->price)
	        node->left = insert(node->left, property);
	    else if (property->price > node->property->price)
	        node->right = insert(node->right, property);
	    else {
	        // Prices are equal, compare locations
	        int locationComparison = node->property->location.compare(property->location);
	        if (locationComparison < 0) {
	            node->right = insert(node->right, property);  // Insert in the right subtree if location is greater
	        } else if (locationComparison > 0) {
	            node->left = insert(node->left, property);  // Insert in the left subtree if location is lesser
	        }
	        // If location is the same, return the node as it is (no duplicate insertion)
	        return node;
	    }
	
	    node->height = max(getHeight(node->left), getHeight(node->right)) + 1;
	
	    int balance = getBalanceFactor(node);
	
	    // Balance the tree if needed
	    if (balance > 1 && property->price < node->left->property->price)
	        return rotateRight(node);
	
	    if (balance < -1 && property->price > node->right->property->price)
	        return rotateLeft(node);
	
	    if (balance > 1 && property->price > node->left->property->price) {
	        node->left = rotateLeft(node->left);
	        return rotateRight(node);
	    }
	
	    if (balance < -1 && property->price < node->right->property->price) {
	        node->right = rotateRight(node->right);
	        return rotateLeft(node);
	    }
	
	    return node;
	}


    void addProperty(Property* property) {
        root = insert(root, property);
    }

    AVLNode* search(AVLNode* node, double price) {
        if (node == NULL || node->property->price == price)
            return node;

        if (price < node->property->price)
            return search(node->left, price);
        else
            return search(node->right, price);
    }

    Property* searchProperty(double price) {
        AVLNode* result = search(root, price);
        return result ? result->property : NULL;
    }

    AVLNode* minValueNode(AVLNode* node) {
        AVLNode* current = node;
        while (current && current->left != NULL)
            current = current->left;
        return current;
    }

    AVLNode* deleteNode(AVLNode* root, double price) {
        if (root == NULL) return root;

        if (price < root->property->price)
            root->left = deleteNode(root->left, price);
        else if (price > root->property->price)
            root->right = deleteNode(root->right, price);
        else {
            if ((root->left == NULL) || (root->right == NULL)) {
                AVLNode* temp = root->left ? root->left : root->right;

                if (temp == NULL) {
                    temp = root;
                    root = NULL;
                }
                else {
                    *root = *temp;
                }
                delete temp;
            }
            else {
                AVLNode* temp = minValueNode(root->right);
                *(root->property) = *(temp->property);
                root->right = deleteNode(root->right, temp->property->price);
            }
        }

        if (root == NULL) return root;

        root->height = max(getHeight(root->left), getHeight(root->right)) + 1;

        int balance = getBalanceFactor(root);

        if (balance > 1 && getBalanceFactor(root->left) >= 0)
            return rotateRight(root);

        if (balance > 1 && getBalanceFactor(root->left) < 0) {
            root->left = rotateLeft(root->left);
            return rotateRight(root);
        }

        if (balance < -1 && getBalanceFactor(root->right) <= 0)
            return rotateLeft(root);

        if (balance < -1 && getBalanceFactor(root->right) > 0) {
            root->right = rotateRight(root->right);
            return rotateLeft(root);
        }

        return root;
    }

    void removeProperty(double price) {
        root = deleteNode(root, price);
    }
	// Helper function to search by location
	AVLNode* searchByLocation(AVLNode* node, const string& location) {
	    if (node == NULL) {
	        return NULL;
	    }
	
	    if (node->property->location == location) {
	        return node; // Property found
	    }
	
	    // Search in the left or right subtree
	    if (location < node->property->location) {
	        return searchByLocation(node->left, location);
	    } else {
	        return searchByLocation(node->right, location);
	    }
	}

	void displayPropertiesInRange(const string& location, double minPrice, double maxPrice) {
    bool found = false;

    // Traverse the tree and display matching properties
    displayPropertiesInRange(root, location, minPrice, maxPrice, found);

    if (!found) {
        cout << "No properties found for location: " << location
             << " within the price range of $" << minPrice << " to $" << maxPrice << "." << endl;
    }
}

void displayPropertiesInRange(AVLNode* node, const string& location, double minPrice, double maxPrice, bool& found) {
    if (!node) return;

    // Search left subtree
    displayPropertiesInRange(node->left, location, minPrice, maxPrice, found);

    // Check if the current node matches the location and price range
    if (node->property->location == location && node->property->price >= minPrice && node->property->price <= maxPrice) {
        found = true; // Update found to true when a match is found
        cout << "Location: " << node->property->location
             << ", Price: $" << node->property->price << endl;
    }

    // Search right subtree
    displayPropertiesInRange(node->right, location, minPrice, maxPrice, found);
}


    void displayInOrder(AVLNode* node) {
        if (!node) return;

        displayInOrder(node->left);
        cout << "Location: " << node->property->location
            << ", Price: $" << node->property->price << endl;
        displayInOrder(node->right);
    }

    void displayProperties() {
        displayInOrder(root);
    }

    void generateGraphviz(AVLNode* node, ofstream& file) {
        if (!node) return;

        if (node->left) {
            file << "\"" << node->property->location << " ($" << node->property->price << ")\" -> \""
                 << node->left->property->location << " ($" << node->left->property->price << ")\";\n";
        }

        if (node->right) {
            file << "\"" << node->property->location << " ($" << node->property->price << ")\" -> \""
                 << node->right->property->location << " ($" << node->right->property->price << ")\";\n";
        }

        generateGraphviz(node->left, file);
        generateGraphviz(node->right, file);
    }

    void exportToGraphviz(const string& filename) {
    ofstream file(filename.c_str());
    	if (!file.is_open()) {
        	cout << "Failed to open file for exporting." << endl;
        	return;
    	}
    	file << "digraph AVLTree {" << endl;
    	file << "    node [shape=ellipse, color=blue, style=filled, fillcolor=lightcyan];" << endl;
    	// Start exporting nodes to Graphviz format
    	exportGraphvizNodes(root, file); // Ensure this function is correctly used
    	file << "}" << endl;
    	file.close();
    	cout << "Tree exported successfully to " << filename << "!" << endl;
	}

	void exportGraphvizNodes(AVLNode* node, ofstream& file) {
    	if (!node) return;
    	// Write the current node
    	file << "    \"" << node->property->location << " ($" << node->property->price << ")\";" << endl;
    	// Write edges to children, if they exist
    	if (node->left) {
        	file << "    \"" << node->property->location << " ($" << node->property->price << ")\" -> \"" 
             	<< node->left->property->location << " ($" << node->left->property->price << ")\";" << endl;
    	}
    	if (node->right) {
        	file << "    \"" << node->property->location << " ($" << node->property->price << ")\" -> \"" 
            	 << node->right->property->location << " ($" << node->right->property->price << ")\";" << endl;
    	}
    // Recursive calls for left and right children
    	exportGraphvizNodes(node->left, file);
    	exportGraphvizNodes(node->right, file);
	}
	
	void generateSearchGraphviz(AVLNode* node, ofstream& file, const string& location, double minPrice, double maxPrice) {
    if (!node) return;

    // Check if the current node matches the search criteria
    bool isMatch = (node->property->location == location && 
                    node->property->price >= minPrice && 
                    node->property->price <= maxPrice);

    // Define node style
    if (isMatch) {
        file << "    \"" << node->property->location << " $" << node->property->price 
             << "\" [style=filled, fillcolor=yellow, fontcolor=black];" << endl;
    } else {
        file << "    \"" << node->property->location << " $" << node->property->price 
             << "\";" << endl;
    }

    // Process the left child
    if (node->left) {
        file << "    \"" << node->property->location << " $" << node->property->price 
             << "\" -> \"" << node->left->property->location << " $" << node->left->property->price << "\";" << endl;
        generateSearchGraphviz(node->left, file, location, minPrice, maxPrice);
    }

    // Process the right child
    if (node->right) {
        file << "    \"" << node->property->location << " $" << node->property->price 
             << "\" -> \"" << node->right->property->location << " $" << node->right->property->price << "\";" << endl;
        generateSearchGraphviz(node->right, file, location, minPrice, maxPrice);
    }
}

	void exportSearchToGraphviz(const string& filename, const string& location, double minPrice, double maxPrice) {
    ofstream file(filename.c_str());
    if (!file.is_open()) {
        cout << "Failed to open file for exporting." << endl;
        return;
    }

    file << "digraph AVLTree {" << endl;
    file << "    node [shape=ellipse, color=blue, style=filled, fillcolor=lightcyan];" << endl;
    
    // Export the filtered properties (only those within the price range)
    generateSearchGraphviz(root, file, location, minPrice, maxPrice);

    file << "}" << endl;
    file.close();
    cout << "Graphviz file created: " << filename << endl;
	}

    void loadPropertiesFromFile(const string& filename) {
        ifstream file(filename.c_str());
        if (!file.is_open()) {
            cout << "File not found. Starting with an empty property list." << endl;
            return;
        }

        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string loc;
            double pr;

            getline(ss, loc, ',');
            if (!(ss >> pr)) {
                cout << "Invalid data format in file. Skipping line." << endl;
                continue;
            }

            Property* newProperty = new Property(loc, pr);
            addProperty(newProperty);
        }

        file.close();
    }

    void savePropertiesToFile(const string& filename) {
        ofstream file(filename.c_str());
        if (!file.is_open()) {
            cout << "Failed to open file for saving." << endl;
            return;
        }
        savePropertiesInOrder(root, file);
        file.close();
        cout << "Properties saved successfully to " << filename << "!" << endl;
    }

    void savePropertiesInOrder(AVLNode* node, ofstream& file) {
        if (!node) return;

        savePropertiesInOrder(node->left, file);
        file << node->property->location << "," << node->property->price << endl;
        savePropertiesInOrder(node->right, file);
    }

    ~AVLTree() {
        clear(root);
    }

    void clear(AVLNode* node) {
        if (!node) return;
        clear(node->left);
        clear(node->right);
        delete node->property;
        delete node;
    }
};


void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}
void displayTreeImage(const string& imagePath) {
#ifdef _WIN32
    // For Windows
    string command = "start " + imagePath;
    system(command.c_str());
#else
    cout << "Unsupported platform. Please open " << imagePath << " manually." << endl;
#endif
}
string intToString(int num) {
    stringstream ss;
    ss << num;
    return ss.str();
}

void displayMenu() {
    const int consoleWidth = 125; // Adjust this to match your console width
    const int menuWidth = 50;    // Width of the menu content
    const int leftPadding = (consoleWidth - menuWidth) / 2;

    // Menu options
    string menuOptions[] = {
        "Add a New Property",
        "Display Available Properties",
        "Search a Property",
        "Update a Property",
        "Delete a Property",
        "Export to Graphviz",
        "Exit"
    };

    // Clear the screen and set red text color
    clearScreen();
    cout << "\033[31m"; // Set text color to red

    // Display header
    cout << string(leftPadding, ' ') << string(menuWidth, '=') << endl;
    cout << string(leftPadding, ' ') << setw(menuWidth / 2 + 10) << " Property Manager Menu" << endl;
    cout << string(leftPadding, ' ') << string(menuWidth, '=') << endl;

    // Loop to display menu options
    for (int i = 0; i < 7; ++i) {
        cout << string(leftPadding, ' ') << left;  // Align text to the left
        cout << setw(5) << (i + 1) << "- " << menuOptions[i] << endl;
    }

    // Display footer
    cout << string(leftPadding, ' ') << string(menuWidth, '-') << endl;
    cout << string(leftPadding, ' ') << setw(menuWidth / 2 + 10) << "Select an Option: ";

    // Reset text color to default
    cout << "\033[0m";
}
void displayHeader(const string& header) {
    const int consoleWidth = 125; // Adjust this to match your console width
    int headerWidth = header.length();
    int leftPadding = (consoleWidth - headerWidth) / 2;

    cout << "\033[31m"; // Set text color to red
    cout << string(leftPadding, ' ') << header << endl;
    cout << string(leftPadding, ' ') << string(headerWidth, '=') << endl;
    cout << "\033[0m"; // Reset text color to default
}

void displayWelcomePage() {
    const int consoleWidth = 125; // Adjust this to match your console width
    const string welcomeMessage = "Welcome to the Property Management System!";
    
    // Clear the screen
    clearScreen();
    cout << "\033[31m"; // Set text color to red

    // Add more space above (e.g., 10 new lines for spacing)
    for (int i = 0; i < 10; ++i) {
        cout << endl; // Add 10 new lines for more vertical space
    }

    // Split the welcome message into words
    istringstream iss(welcomeMessage);
    string word;

    // Display each word with a delay
    string fullMessage; // To keep track of the full message as it builds
    while (iss >> word) {
        fullMessage += word + " "; // Append the word to the full message
        int leftPadding = (consoleWidth - fullMessage.length()) / 2; // Recalculate left padding
        cout << string(leftPadding, ' ') << fullMessage << flush; // Print the full message centered
        std::this_thread::sleep_for(std::chrono::milliseconds(500)); // Delay for 500 milliseconds
        clearScreen(); // Clear the screen for the next word
        for (int i = 0; i < 10; ++i) {
            cout << endl; // Maintain spacing after clearing
        }
    }

    // Add space below
    cout << endl << endl; // Two new lines for spacing

    // Reset text color to default
    cout << "\033[0m"; // Reset text color to default
    std::this_thread::sleep_for(std::chrono::seconds(2)); // Pause for 2 seconds before proceeding
}
int main() {
	displayWelcomePage();
	int opt;
	double pp, op, np, dp;
	string location;
	double price;
	AVLTree propertyManager;

	// File operations
	const string filename = "Properties.txt";
	const string dotFilename = "D:\\Proj_DSA\\avltree.dot";

	propertyManager.loadPropertiesFromFile(filename);

	while (true) {
	  displayMenu();
	  cin >> opt;
	  if (cin.fail()) {
	    cin.clear();
	    cin.ignore(numeric_limits < streamsize > ::max(), '\n');
	    cout << "Invalid option. Try again." << endl;
	    continue;
	  }
	  cin.ignore(numeric_limits < streamsize > ::max(), '\n');
	  clearScreen();
	  switch (opt) {
	  case 1: {
	    clearScreen();
	    displayHeader("Add Property");

	    string location;
	    double price;

	    cout << "Enter property location: ";
	    getline(cin, location);

	    cout << "Enter property price: ";
	    while (!(cin >> price) || price < 0) {
	      cout << "Invalid input! Price must be a positive number: ";
	      cin.clear();
	      cin.ignore(numeric_limits < streamsize > ::max(), '\n');
	    }

	    cin.ignore(numeric_limits < streamsize > ::max(), '\n'); // Clear input buffer

	    Property * newProperty = new Property(location, price);
	    propertyManager.addProperty(newProperty);
	    cout << "Property added successfully!" << endl;

	    // Save updated properties to file
	    propertyManager.savePropertiesToFile("Properties.txt");

	    Sleep(4000); // Pause for 2000 milliseconds
	    clearScreen(); // Clear the screen after the pause
	    break;
	  }

	  case 2: {
	    clearScreen();
	    displayHeader("Display Properties");

	    propertyManager.displayProperties();

	    Sleep(4000); // Pause for 2000 milliseconds
	    clearScreen(); // Clear the screen after the pause
	    break;
	  }

	  case 3: {
	    clearScreen();
	    displayHeader("Search Property");

	    // Ask for the location first
	    cout << "Enter the location of the property you're looking for: ";
	    getline(cin, location);

	    // Ask for the price range
	    double minPrice, maxPrice;
	    cout << "Enter the minimum price: ";
	    cin >> minPrice;
	    cout << "Enter the maximum price: ";
	    cin >> maxPrice;

	    if (cin.fail() || minPrice < 0 || maxPrice < 0 || minPrice > maxPrice) {
	      cin.clear();
	      cin.ignore(numeric_limits < streamsize > ::max(), '\n');
	      cout << "Invalid price range." << endl;
	      break;
	    }

	    // Export the filtered tree to Graphviz
	    const string dotFilename = "filtered_properties.dot";
	    const string pngFilename = "filtered_properties.png";
	    propertyManager.exportSearchToGraphviz(dotFilename, location, minPrice, maxPrice);

	    // Generate the PNG file as usual
	    string command = "dot -Tpng " + dotFilename + " -o " + pngFilename;
	    int result = system(command.c_str());
	    if (result == 0) {
	      cout << "Tree image created: " << pngFilename << endl;
	      displayTreeImage(pngFilename);
	    } else {
	      cout << "Failed to generate tree image. Ensure Graphviz is installed and added to PATH." << endl;
	    }

	    // Search for properties within the price range and matching the location
	    propertyManager.displayPropertiesInRange(location, minPrice, maxPrice);

	    Sleep(6000); // Pause for 2000 milliseconds
	    clearScreen(); // Clear the screen after the pause
	    break;
	  }

	  case 4: {
	    clearScreen();
	    displayHeader("Update Property");
	    string loc;
	    double oldP, newP;

	    // Get property location
	    cout << "Enter property location: ";
	    getline(cin, loc);

	    // Get current price
	    cout << "Enter current price: ";
	    while (!(cin >> oldP) || oldP < 0) {
	      cout << "Invalid price. Please enter a valid positive number: ";
	      cin.clear();
	      cin.ignore(numeric_limits < streamsize > ::max(), '\n');
	    }

	    // Get new price
	    cout << "Enter new price: ";
	    while (!(cin >> newP) || newP < 0) {
	      cout << "Invalid price. Please enter a valid positive number: ";
	      cin.clear();
	      cin.ignore(numeric_limits < streamsize > ::max(), '\n');
	    }
	    cin.ignore(numeric_limits < streamsize > ::max(), '\n'); // Clear any remaining input

	    // Search for the property to update
	    AVLNode * current = propertyManager.root;
	    bool found = false;

	    while (current != NULL) {
	      if (current -> property -> price == oldP && current -> property -> location == loc) {
	        found = true;
	        break;
	      } else if (oldP < current -> property -> price) {
	        current = current -> left;
	      } else {
	        current = current -> right;
	      }
	    }

	    // Update or handle not found
	    if (!found) {
	      cout << "Property not found!" << endl;
	    } else {
	      propertyManager.removeProperty(oldP);
	      Property * updatedProperty = new Property(loc, newP);
	      propertyManager.addProperty(updatedProperty);

	      cout << "Property updated successfully!" << endl;

	      // Save updated tree to file
	      propertyManager.savePropertiesToFile("properties.txt");

	      // Export updated tree to Graphviz
	      propertyManager.exportToGraphviz("updated_tree.dot");

	      // Generate tree image
	      string command = "dot -Tpng updated_tree.dot -o updated_tree.png";
	      int result = system(command.c_str());
	      if (result == 0) {
	        cout << "Updated tree image created: updated_tree.png" << endl;
	        displayTreeImage("updated_tree.png");
	      } else {
	        cout << "Failed to generate tree image. Check Graphviz installation." << endl;
	      }
	    }

	    Sleep(4000); // Pause for 2000 milliseconds
	    clearScreen(); // Clear the screen after the pause
	    break;
	  }

	  case 5: {
	    clearScreen();
	    displayHeader("Delete Property");

	    string loc;
	    double dp;

	    cout << "Enter the location of the property to delete: ";
	    getline(cin, loc);

	    cout << "Enter the price of the property to delete: ";
	    while (!(cin >> dp) || dp < 0) {
	      cout << "Invalid price. Please enter a valid positive number: ";
	      cin.clear();
	      cin.ignore(numeric_limits < streamsize > ::max(), '\n');
	    }
	    cin.ignore(numeric_limits < streamsize > ::max(), '\n'); // Clear input buffer

	    AVLNode * current = propertyManager.root;
	    bool found = false;

	    while (current != NULL) {
	      if (current -> property -> price == dp && current -> property -> location == loc) {
	        found = true;
	        break;
	      } else if (dp < current -> property -> price) {
	        current = current -> left;
	      } else {
	        current = current -> right;
	      }
	    }

	    if (!found) {
	      cout << "Property with location \"" << loc << "\" and price " << dp << " not found!" << endl;
	    } else {
	      propertyManager.removeProperty(dp);
	      cout << "Property with location \"" << loc << "\" and price " << dp << " successfully deleted!" << endl;
	      propertyManager.savePropertiesToFile("properties.txt");
	    }

	    Sleep(4000); // Pause for 2000 milliseconds
	    clearScreen(); // Clear the screen after the pause
	    break;
	  }

	  case 6: {
	    clearScreen();
	    displayHeader("Exporting to graphwiz");
	    const string dotFilename = "avltree.dot";
	    const string imageFilename = "avltree.png";

	    // Export the tree to a DOT file
	    propertyManager.exportToGraphviz(dotFilename);
	    cout << "Graphviz file created: " << dotFilename << endl;

	    // Run the Graphviz command to generate an image
	    string command = "dot -Tpng " + dotFilename + " -o " + imageFilename;
	    int result = system(command.c_str());

	    if (result == 0) {
	      cout << "Tree image created: " << imageFilename << endl;
	      // Display the PNG image
	      displayTreeImage(imageFilename);
	      propertyManager.savePropertiesToFile(filename);
	    } else {
	      cout << "Failed to generate tree image. Ensure Graphviz is installed and added to PATH." << endl;
	    }
	    Sleep(4000); // Sleep for 2000 milliseconds
	    clearScreen(); // Clear the screen after the sleep
	    break;
	  }

	  case 7: {
	    propertyManager.savePropertiesToFile(filename);
	    cout << "Exiting program. Goodbye!" << endl;
	    return 0;
	  }

	  default: {
	    cout << "Invalid option. Try again." << endl;
	    break;
	  }
	  }
	}

	return 0;
	}